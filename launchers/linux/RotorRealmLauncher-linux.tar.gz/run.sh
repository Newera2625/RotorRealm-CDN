#!/bin/bash
# RotorRealm 启动器 Linux 版（mono 运行）
cd "$(dirname "$0")"
if ! command -v mono >/dev/null 2>&1; then
  echo "未检测到 mono，请先安装："
  echo "  Debian/Ubuntu:  sudo apt install mono-complete"
  echo "  Arch:           sudo pacman -S mono"
  echo "  Fedora:         sudo dnf install mono-devel"
  exit 1
fi
mono RotorRealmLauncher.exe "$@"
