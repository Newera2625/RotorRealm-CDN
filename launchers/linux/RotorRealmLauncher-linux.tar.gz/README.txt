RotorRealm 启动器 - Linux 版
============================
与 Windows 版共用同一程序，Linux 下通过 mono 运行。

使用方法：
1. 安装 mono：sudo apt install mono-complete（Debian/Ubuntu）
2. 解压本压缩包
3. 运行：./run.sh  或  mono RotorRealmLauncher.exe

功能与 Windows 版一致：SSO 登录、游戏启动、MOD 增量更新、自动内存分配、设置等。
